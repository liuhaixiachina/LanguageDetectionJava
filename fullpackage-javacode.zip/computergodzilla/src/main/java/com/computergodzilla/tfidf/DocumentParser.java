/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.computergodzilla.tfidf;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.List;

/**
 * Class to read documents
 *
 * @author Mubin Shrestha
 */
public class DocumentParser {

    //This variable will hold all terms of each document in an array.
    
//    private List<String[]> termsDocsArray = new ArrayList<String[]>();
//    private List<String> docfileNames = new ArrayList<String>();
    private List<String[]> termsDocsArraywhole = new ArrayList<String[]>();  
    private List<String[]> termsDocsArraygrt = new ArrayList<String[]>();    
    private List<String[]> termsDocsArraytest = new ArrayList<String[]>();
    private List<String> docfileNamesgrt = new ArrayList<String>();
    private List<String> docfileNamestest = new ArrayList<String>();
    private List<String> allTerms = new ArrayList<String>(); //to hold all terms
    private List<double[]> tfidfDocsVectorgrt = new ArrayList<double[]>();
    private List<double[]> tfidfDocsVectortest = new ArrayList<double[]>();
    private int nrealfiles = 0;
    

    /**
     * Method to read files and store in array.
     * @param filePath : source file path
     * @throws FileNotFoundException
     * @throws IOException
     * * haixia modify
     */
                
    public void parseFiles(String filePath) throws FileNotFoundException, IOException {		
        File[] allfiles = new File(filePath).listFiles();
        BufferedReader in = null;
        
        for (File f : allfiles) {
            if (f.getName().endsWith(".txt")) {
//                String strGtr = f.getName().split("-")[0];//get ground truth
                in = new BufferedReader(new FileReader(f));
                StringBuilder sb = new StringBuilder();
                String s = null;
                while ((s = in.readLine()) != null) {
                    sb.append(s);
                }
                String[] tokenizedTerms = sb.toString().replaceAll("[\\W&&[^\\s]]", "").split("\\W+");   //to get individual terms
                for (String term : tokenizedTerms) {
                    if (!allTerms.contains(term)) {  //avoid duplicate entry
                        allTerms.add(term);
                    }
                } 
                //add ALL for calculating tf idf. because idf is based on the FULL pool: counting the total number of docs that contain the term
                termsDocsArraywhole.add(tokenizedTerms);
                if (f.getName().contains("short")){                    
                termsDocsArraytest.add(tokenizedTerms);
                docfileNamestest.add(f.getName()); 
                } 
                else{
                termsDocsArraygrt.add(tokenizedTerms);
                docfileNamesgrt.add(f.getName()); 
                }
                            
            }
            
        }
    }
//    public void parseFiles(String filePath) throws FileNotFoundException, IOException {
//        //add test file        
//        String testfile=filePath+"/el-1.txt";
//        BufferedReader br= new BufferedReader(new FileReader(new File(testfile)));
//        StringBuilder sbtest = new StringBuilder();
//        String stest = null;
//        while ((stest = br.readLine()) != null) {
//            sbtest.append(stest);
//        }
//        String[] tokenizedTermstest = sbtest.toString().replaceAll("[\\W&&[^\\s]]", "").split("\\W+");   //to get individual terms
//        for (String term : tokenizedTermstest) {
//            if (!allTerms.contains(term)) {  //avoid duplicate entry
//                allTerms.add(term);
//            }
//        }
//        termsDocsArray.add(tokenizedTermstest);
//        docfileNames.add("de-1.txt");
//        //end add test file      
//		
//        File[] allfiles = new File(filePath).listFiles();
//        BufferedReader in = null;
//        
//        for (File f : allfiles) {
//            if (f.getName().endsWith(".txt") && !f.getName().contains("test")) {            
//                in = new BufferedReader(new FileReader(f));
//                StringBuilder sb = new StringBuilder();
//                String s = null;
//                while ((s = in.readLine()) != null) {
//                    sb.append(s);
//                }
//                String[] tokenizedTerms = sb.toString().replaceAll("[\\W&&[^\\s]]", "").split("\\W+");   //to get individual terms
//                for (String term : tokenizedTerms) {
//                    if (!allTerms.contains(term)) {  //avoid duplicate entry
//                        allTerms.add(term);
//                    }
//                }                
//                termsDocsArray.add(tokenizedTerms);
//                docfileNames.add(f.getName());              
//            }//end if contains "test"
//        }
//    }
    
    public void tfIdfCalculator() {
        double tf; //term frequency
        double idf; //inverse document frequency
        double tfidf; //term requency inverse document frequency    
        int doccount=0;
        //process ground truth files
        for (String[] docTermsArray : termsDocsArraygrt) {
            doccount++;
            double[] tfidfvectors = new double[allTerms.size()];
            int count = 0;
            for (String terms : allTerms) {
                tf = new TfIdf().tfCalculator(docTermsArray, terms);
                idf = new TfIdf().idfCalculator(termsDocsArraywhole, terms);
                tfidf = tf * idf;                
                DecimalFormat df = new DecimalFormat("0.000");
                df.format(tfidf);
                tfidfvectors[count] = tfidf;
                count++;
            }
            
            tfidfDocsVectorgrt.add(tfidfvectors);  //storing document vectors; but lost file name;          
        }
        //process test files
        for (String[] docTermsArray : termsDocsArraytest) {
            doccount++;
            double[] tfidfvectors = new double[allTerms.size()];
            int count = 0;
            for (String terms : allTerms) {
                tf = new TfIdf().tfCalculator(docTermsArray, terms);
                idf = new TfIdf().idfCalculator(termsDocsArraywhole, terms);
                tfidf = tf * idf;                
                DecimalFormat df = new DecimalFormat("0.000");
                df.format(tfidf);
                tfidfvectors[count] = tfidf;
                count++;
            }
            
            tfidfDocsVectortest.add(tfidfvectors);  //storing document vectors; but lost file name;          
        }
    }

    /**
     * Method to save tfidf vectors, for future use, for saving time
     * author:haixia
     */
    public void savegrtfilestfidf(String fpath) throws IOException{                
        String strOutPutDir = fpath;
//        "/home/ocean/NetBeansProjects/computergodzilla/data/";
        String strOutFile = "sth.csv";
        String strOutPut = strOutPutDir + "/" + strOutFile;
        FileWriter fwSentences = new FileWriter(strOutPut);
        String docname="";
        
        for (int j = 0; j < tfidfDocsVectorgrt.size(); j++) {
            docname = docfileNamesgrt.get(j);
            int nlen = tfidfDocsVectorgrt.get(j).length;
            String strvec = "";
            for (int k = 0; k < nlen; k++) {
                String strtemp = Double.toString(tfidfDocsVectorgrt.get(j)[k]);
                strvec = strvec + strtemp+",";
            }
            fwSentences.write(docname+','+strvec+'\n');
            }
        fwSentences.flush();
        fwSentences.close();
        
    }
    
    /**
     * Method to calculate cosine similarity between all the documents.
     * haixia modify
     */
    public void getCosBetweenTestandDatabse() {
        double ntestfiles = 0.0;
        double ncorrect = 0.0;
        for (int i = 0; i < tfidfDocsVectortest.size(); i++) { 
            ntestfiles++;
            //get ground truth
            String[] strgetfname = docfileNamestest.get(i).split("-");
            String strlnamegrt = "";
            if (strgetfname.length>0){
                strlnamegrt = strgetfname[0].toString().toLowerCase();;               
            }  
            double maxscore = -1.0;
            String strpredictedlname = "";
            for (int j = 0; j < tfidfDocsVectorgrt.size(); j++) {
//                System.out.println("between " + docfileNamestest.get(i) + " and " + docfileNamesgrt.get(j) + "  =  "
//                                   + new CosineSimilarity().cosineSimilarity
//                                       (
//                                         tfidfDocsVectortest.get(i), 
//                                         tfidfDocsVectorgrt.get(j)
//                                       )
//                                  );
                double dbscore = new CosineSimilarity().cosineSimilarity
                                       (
                                         tfidfDocsVectortest.get(i), 
                                         tfidfDocsVectorgrt.get(j)
                                       );
                if (dbscore > maxscore){
                    maxscore = dbscore;
                    //get predicted language name
            String[] strgetpredictnamelist = docfileNamesgrt.get(j).split("-");
            if (strgetfname.length>0){
                strpredictedlname = strgetpredictnamelist[0].toString().toLowerCase();;               
            } 
                    
                }
            }
            if (strpredictedlname == ""){
                System.out.println("Cannot predict.");
                System.out.println("Grt: "+ strlnamegrt);
                System.out.println("**********************************");
            }
            else{
//                System.out.println("The highest cosine score is "+ maxscore);
//                System.out.println("I guess it is written in: "+ strpredictedlname.replace("-1.txt", ""));                   
                if (strpredictedlname.contains(strlnamegrt)){
                    ncorrect++;
                }
                else{
                    System.out.println("Grt: "+ strlnamegrt);
                    System.out.println("Detected: "+ strpredictedlname);
                    System.out.println("**********************************");
                }
//                System.out.println("Grt: "+ strlnamegrt);
//                System.out.println("Detected: "+ strpredictedlname);
            }
        }
        double acc = (double) (ncorrect / ntestfiles);
        System.out.println("Total test files: "+ ntestfiles);
        System.out.println("Correctly detected: "+ ncorrect);
        System.out.println("Accuracy: "+ acc);
        
    }
}
