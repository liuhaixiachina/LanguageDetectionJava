IDme encodes three algorithms for identifying language of input texts.
It was implemented under Ubuntu 14.04, NetBeans IDE 8.0.
The main class is located in the file : IDme.java
It doesn't take arguments list, you can give it a try by 
following the instructions:
=====================Instructions=====================================
1. dataset location:
The tested text files are in the folder 'data'.
In the file IDme.java, search for "//tag:change it to your file-folder",
and you will find this line:
private final String filepath = "/home/ocean/Documents/data/";

2. Three language detection algorithms:
        //*********IDme-byTfIdf*****************
        //command.idmebytfidf();
        //*********IDme-byLRC1*****************
        double strresultdist = command.idmebydistribution(command.filepath);
        //*********IDme-byLRC2*****************
        //double strresultonehot = command.idmebyonehot(command.filepath); 

I would recommend you try the algorithm 'idmebydistribution', 
because the other two algorithms take longer time to process. But if you want 
to try 'idmebytfidf', you'd better use the dataset '/data/tfidf/', which has 
files with only sentence each.

3.If you want to test your own text file, change your file name according 
to the following format:

languagename-yourfilename.txt
e.g.: de-file1.txt

Welcome to email me : khx3lhi at nottingham dot edu dot my.
Thanks.

-Haixia Liu
March.2016
